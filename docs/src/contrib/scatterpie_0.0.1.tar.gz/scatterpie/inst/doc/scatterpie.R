## ----style, echo=FALSE, results="asis", message=FALSE--------------------
knitr::opts_chunk$set(tidy = FALSE,
		   message = FALSE)

## ----echo=FALSE, results="hide", message=FALSE---------------------------
library("ggplot2")
library("scatterpie")

## ------------------------------------------------------------------------
set.seed(123)
long <- rnorm(50, sd=100)
lat <- rnorm(50, sd=50)
d <- data.frame(long=long, lat=lat)
d <- with(d, d[abs(long) < 150 & abs(lat) < 70,])
n <- nrow(d)
d$region <- factor(1:n)
d$A <- abs(rnorm(n, mean=5))
d$B <- abs(rnorm(n, mean=5))
d$C <- abs(rnorm(n, mean=5))
d$D <- abs(rnorm(n, mean=5))
d[1, 4:7] <- d[1, 4:7] * 3
head(d)

## ----fig.width=10--------------------------------------------------------
ggplot() + geom_scatterpie(aes(x=long, y=lat, group=region), data=d,
                           cols=LETTERS[1:4], scale_fun=function(x) 5) + coord_equal()

## ----fig.width=10--------------------------------------------------------
ggplot() + geom_scatterpie(aes(x=long, y=lat, group=region), data=d,
                           cols=LETTERS[1:4], scale_fun=function(x) 30* x/sum(x), color=NA) + coord_equal()

## ----fig.width=10--------------------------------------------------------
d$radius <- 6
ggplot() + geom_scatterpie(aes(x=long, y=lat, group=region, r=radius), data=d,
                           cols=LETTERS[1:4], color=NA) + coord_equal()

## ----fig.width=10--------------------------------------------------------
world <- map_data('world')
p <- ggplot(world, aes(long, lat)) +
    geom_map(map=world, aes(map_id=region), fill=NA, color="black") +
    coord_quickmap()
p + geom_scatterpie(aes(x=long, y=lat, group=region), data=d,
                    cols=LETTERS[1:4], scale_fun=function(x) 5, color=NA, alpha=.8)

## ----echo=FALSE----------------------------------------------------------
sessionInfo()

