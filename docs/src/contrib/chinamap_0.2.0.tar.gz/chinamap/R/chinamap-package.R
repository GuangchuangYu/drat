
#' Datasets
#'
#' China map
#'
#'
#' @name DataSet
#' @aliases china
#' @docType data
#' @keywords datasets
NULL
