downloaded from http://cos.name/wp-content/uploads/2009/07/chinaprovinceborderdata_tar_gz.zip

reference:
http://cos.name/2009/07/drawing-china-map-using-r/
http://cos.name/2014/08/r-maps-for-china/

